const answerDb = require('./models/answers')
const questionDb = require('./models/questions')
const tagDb = require('./models/tags')
const userDb = require('./info/user.js')

const mongodb = require("mongoose");
const mongourl = "mongodb://127.0.0.1:27017/fake_so"
mongodb.connect(mongourl)

const port = 8000;

const express = require("express")
const cors = require('cors');

const app = express()
app.use(cors());

app.use(express.json());
app.use(express.urlencoded({extended:true}));



app.get('/tags', async (req, res) => {

    tagDb.find({},(err,resT) => {
        if(err) {
            res.send(err)
        }
        else
        {
            res.send(resT)
        }
    })
});

app.get('/answers', async (req, res) => {

    answerDb.find({},(err,resA) => {
        if(err) {
            res.send(err)
        }
        else
        {
            res.send(resA)
        }
    })
});

app.get('/questions', async (req, res) => {

    questionDb.find({},(err,resQ) => {
        if(err) {
            res.send(err)
        }
        else
        {
            res.send(resQ)
        }
    })
});

app.get('/users', async(req,res) => {
    userDb.find({},(err,resQ) => {
        if(err) {
            res.send(err)
        }
        else {
            res.send(resQ)
        }
    })
});

app.post('/addTag', async(req, res) => {
    try{
    let newTag = new tagDb({name: req.body.name});
    await newTag.save()
    res.json(newTag);
    }
    catch (error) {
        res.send(error);
    }
  })

app.post('/addQuestion', async(req, res) => {
    try{
    const {title, text, tags, answers, asked_by, ask_date_time, views} = req.body
    let newQuestion = new questionDb({title, text, tags, answers, asked_by, ask_date_time, views});
    res.send()
    await newQuestion.save()
    }
    catch (error) {
        res.send(error);
    }
})

app.post('/addAnswer', async(req, res) => {
    try {
    const {text, ans_by, ans_date_time} = req.body
    let newAnswer = new answerDb({text, ans_by, ans_date_time});
    // res.send()
    await newAnswer.save()
    }
    catch(error) {
        res.send(error);
    }
})  

app.post('/addUser', async(req,res) => {
    try{
    const {username, password, email} = req.body;
    let newUser = new userDb({username, password, email});
    await newUser.save();
    console.log(newUser)
    }
    catch(err) {
        console.log(err)
    }
});

app.put('/updateQuestion', async(req,res) => {
    
    const updateQuestion = req.body.upAns;
    const id = req.body.id
    // console.log(id._id);
    // console.log(questionDb.findById(id._id));
    // console.log(updateQuestion);
    try {
            await questionDb.findById(id._id, (error, questionToUpdate) => {
            questionToUpdate.answers.unshift(updateQuestion)
            questionToUpdate.views++;
            questionToUpdate.save();
            // console.log(error);
        }).clone();
    }
    catch(err) {
        console.log(err);
    }
    res.send("Updated");


    // let updateQuestion = new answerDb({text,ans_by,ans_date_time});
    // await updateQuestion.save();
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})