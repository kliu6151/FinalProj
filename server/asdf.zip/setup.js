//MySQL Schema setup if using MySQL
