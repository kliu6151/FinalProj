// Answer Document Schema

var mongoose = require('mongoose')
  , Schema = mongoose.Schema

var answerSchema = new Schema({
    text: String,
    ans_by: String,
    ans_date_time: {type: Date, default: Date.now}

    // url: String
});
    
answerSchema
.virtual('url')
.get(function () {
  return '/post/answer/' + this._id;
});

module.exports = mongoose.model('Answer', answerSchema);
