import styles from './questions.module.css'
import React from 'react';


class Questions extends React.Component {
    constructor(props) {
        super(props);
        
    }

    render() {

    return (
            <div id = {styles["Questions"]}>
                <table id = {styles["QHeader"]}>
                    <tbody>
                        <tr id = {styles["headings"]}>
                            <th id = {styles["H1"]}> <span id = {styles["QCounter"]}>{this.props.numQuestions}</span> <span id = {styles["QorA"]}>{this.props.sectionType}</span></th>
                            <th id = {styles["H2"]}>{this.props.titleQuestions}</th>
                            <th id = "H3">
                                <button id = {styles["AMA"]} onClick={this.props.handlerHidingForQForms}>Ask A Question</button>

                            </th>
                        </tr>
                    </tbody>
                </table>
            </div>
    );
    }   
}


export default Questions;