import React from 'react';
import styles from './validQ.module.css'


class ValidTag extends React.Component {
    constructor(props) {
        super(props)
    }
    
    render() {
        return (
            <div className = {styles.invalidQ}>Tags cannot be empty</div>

        );
    }

}

export default ValidTag;