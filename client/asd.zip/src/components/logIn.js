import styles from './logIn.module.css';
import React from 'react';



class LogIn extends React.Component {
    constructor(props) {
        super(props);
        
    }

    //Go into the database to see if the user exists
    isValidLogIn =  () => {
        console.log(document.getElementById(styles["logPass"]))
        let U = {
            user: document.getElementById(styles["logName"]).value,
            email: document.getElementById(styles["logEmail"]).value,
            password: document.getElementById(styles["logPass"]).value
          };
        this.handlerForReturningUser(U);
    }

    render() {

    return (
        <div id = {styles["bg"]}> <span id = {styles["title"]}>Log In Page</span>
            <div className={styles.logIn}>
                <div id = {styles["wholeForm"]}>
                    
                    <label>
                        <b>Email</b>    
                    </label>   
                    <input type="text" name="Email" id={styles["logEmail"]} placeholder="Email" />   
                    <br/>

                    <label>
                        <b>Password</b>    
                    </label> 
                    <input type="text" name="Pass" id={styles["logPass"]} placeholder="Password" />   
                    <br/>

                    <input type="button" name="log" id={styles["log"]} value="Log In Here" onClick = {this.isValidLogIn} />   
                    <br/>

                    <div id = {styles["newUser"]}>New User? <span onClick = {this.signUp} id = {styles["signUp"]}>Sign Up</span></div>
                    <div id = {styles["guest"]} onClick = {this.guestMode}>Continue As Guest</div>

                </div>
            </div>
        </div>
    );
    }   
}

export default LogIn;