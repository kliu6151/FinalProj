import styles from './insideQuestion.module.css'
import React from 'react';

class InsideQ extends React.Component {
    constructor(props) {
        super(props);
    }

    clickSpecA = (e) => {
        this.props.handlerChangingSpecificA(e)
    }

    render() {
    var quest = this.props.specificQ;
    var ans = this.props.answerData;
    
    // console.log(quest);

    return (
        <>
        <table className = {styles.wholeAnswerTable}>
            <tbody>
                <tr>
                    <td className = {styles.firstCol}>
                        {++quest.views} Views
                    </td>
                    <td className = {styles.secondCol}>
                        {quest.text}
                    </td>
                    <td className = {styles.thirdCol}>
                        <span className = {styles.ansBy}>
                        Asked By {quest.asked_by}
                        </span>
                        <br />
                        <span className = {styles.ansOn}>
                        On {this.generateDate(quest.ask_date_time)}
                        </span>
                        <br />
                        <span className = {styles.ansAt}>
                        At {this.generateTime(quest.ask_date_time)}
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
             <hr id = {styles["horiLine"]}/>
        <table className = { styles.wholeAnswerTable}>
            <tbody>
                {/* <tr> */}
                    {this.generateAnswers(quest.answers,ans).map((name)=>(
                        <>
                        <tr>
                            <td className = {styles.answerText}>
                                {name.text}
                            </td>
                            <td className = {styles.thirdCol}>
                                <span className = {styles.ansBy}>
                                Ans By {name.ans_by} 
                                </span>
                                <br />
                                <span className = {styles.ansOn}>
                                On {this.generateDate(name.ans_date_time)} 
                                </span>
                                <br />
                                <span className = {styles.ansAt}>
                                At {this.generateTime(name.ans_date_time)} 
                                </span>
                            </td>
                        </tr>
             <hr id = {styles["horiLine"]}/>
                        </>
                    ))}
                {/* </tr> */}
            </tbody>
        </table>
                  <div id = {styles["answerButtonContainer"]}><button id = {styles["answerButton"]} onClick={(e) => this.clickSpecA(e)}>Answer Question</button></div>

        </>
    );
}

generateDate = (curDate) => {
    const d1 = new Date(curDate).toLocaleDateString('en-US');
    return d1;
}

generateTime = (curDate) => {
    const d1 = new Date(curDate).toLocaleTimeString('en-US');
    return d1;
}



  generateAnswers = (qAnsArr, allAnsArr) => {
      let arrName = [];
    for (let i = 0; i < qAnsArr.length; i++) {
        // console.log(qAnsArr);
        for(let j = 0; j < allAnsArr.length; j++) {
            // console.log(allAnsArr[j].text + "\n");
            // console.log(qAnsArr[i].text + "\n");
            if(qAnsArr[i].text === allAnsArr[j].text) {
                // console.log("HU");
                arrName.push(allAnsArr[j]);
            }
        }
    }
    return arrName;
  }
   
}

export default InsideQ;
