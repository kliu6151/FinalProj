import styles from './answerForm.module.css';
import React from 'react';
import ValidText from './validA/validText'
import ValidUser from './validA/validUser'




class AnswerForm extends React.Component {
    constructor(props) {
        super(props);
        this.state =  {
            inValidText: false,
            inValidName: false, 
            invalidSpecUser: "invalid user"
        }
    }
    
    handlerInvalidText () {
        this.setState({
            inValidText: true
        })
    }
    handlerInvalidUser(userE) {
        this.setState({
            inValidName: true,
            invalidSpecUser: userE
        })
    }
    handlerValidText () {
        this.setState({
            inValidText: false
        })
    }
    handlerValidUser() {
        this.setState({
            inValidName: false
        })
    }


    isValidA = () =>  {

        
    let QText = document.getElementById(styles["AText"]);
    let QName = document.getElementById(styles["AUser"]);
    if (QText.value.length-1 === 0) {
        this.handlerInvalidText()
    }
    else {
        this.handlerValidText()
    }
    if (QName.value.length > 15) {
      let temp = "Username cannot be greater than 15 characters"
      this.handlerInvalidUser(temp)
    }
    else if (QName.value.length === 0) {
      let temp = "Username cannot be 0 characters";
      this.handlerInvalidUser(temp);
    }
    else {
        this.handlerValidUser()
    }
    //IF ALL IS TRUE RUN SUBMIT QUESTION()
    this.submitAnswer()
  }




    submitAnswer = () =>{
      
    
    let A = {
      text: document.getElementById(styles["AText"]).value,
      ans_by: document.getElementById(styles["AUser"]).value,
    };
        try{
        this.props.handlerModelAUpdate(A)
        }
        catch (error) {
            console.log(error)
        }
    }

    render() {
            const{inValidText, inValidName} = this.state

    return (
        <div id = "AnswerForm">

        {inValidText && <ValidText />}
        {inValidName && <ValidUser invalidSUser = {this.state.invalidSpecUser} />}

            <label for = "AText" id = {styles["AT1"]}>Answer Text</label>
            <textarea id = {styles["AText"]} name = "AText"> </textarea> 

            <label for = "AUser" id = {styles["AU"]}>Username</label> <br /> 
            <input type = "text" id = {styles["AUser"]} name = "AUser" />

            <input type = "submit" id = {styles["APost"]} value = "Answer Question" onClick = {this.isValidA} />
        </div>


    )
    }
}

export default AnswerForm;